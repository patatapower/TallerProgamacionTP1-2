const fs = require('fs')

function findMin(valores){
    return Math.min.apply(null, valores);
   
}


let str = new Array(3);

str[0] = [10, 123, 456, 789]; 
str[1] = [5, 100, 500, 600];
str[2] = [7, 95, 451, 550]

let separador = [5, 100, 500, 4, 600]
let respuesta = findMin(separador);
console.log(respuesta);