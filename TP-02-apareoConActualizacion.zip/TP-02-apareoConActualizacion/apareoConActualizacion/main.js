const ap = require('./apareoConActualizacion');
const fs = require('fs');

const rutaDeudasOld = './in/deudasOLD.json'
const rutaPagos = './in/pagos.json'
const rutaDeudasNew = './out/deudasNEW.json'
const rutaLog = './out/notificaciones.log'


// let logger = function(myobjeto){
//     fs.appendFileSync('./logger.txt', myObjeto);
// }

ap.actualizarArchivosDeudas(rutaDeudasOld, rutaPagos, rutaDeudasNew, rutaLog)

